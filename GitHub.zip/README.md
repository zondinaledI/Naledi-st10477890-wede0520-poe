](../../Desktop/Mywebsite/.gitignore)#Signature Store Project Documentation
## Project overvire
* **Developer:** Naledi Zondi
* **Project Name:** Signature Retail Store
* **Course Code:** WEDE0520

### 1. Images and Logos
* **Banner Image:**
unsplash (2026) *Elegant glass perfumes bottles on marbles*. Avaialable at : https://unplash.com

### 2. Code
* **Google Maps Iframe :**
Google Maps (2026) *Embed map code generator API*. Available at: https://google.com
 